# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.apps import AppConfig


class NewsConfig(AppConfig):
    name = 'game'
    verbose_name = "搜索引擎数据详细信息"
