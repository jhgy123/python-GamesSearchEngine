# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
# from .models import game

#class newsAdmin(admin.ModelAdmin):
#	list_display('title','time','body')

# admin.site.register(game)

# Register your models here.
