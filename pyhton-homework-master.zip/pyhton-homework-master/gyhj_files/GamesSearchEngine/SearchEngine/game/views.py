# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from urllib import request
from django.shortcuts import render
# game.page import PageInfo
from django.core.paginator import Paginator

import time
import sqlite3
# import re
from .models import Data
import jieba
import re

def search_form(request,pagenum):
	# allnews = game.objects.all()
	allnews = Data.objects.all()
	pag = Paginator(allnews, 10)
	newslist = pag.page(pagenum)
	return render(request,'search_form.html',{'all_news':newslist})

# Create your views here.

def search_form(request, pagenum):
	# allnews = game.objects.all()
	allnews = Data.objects.all()
	pag = Paginator(allnews, 10)
	newslist = pag.page(pagenum)
	return render(request, 'search_form.html', {'all_news': newslist})


def search(request, pagenum):
	q = request.GET['q']
	pattern = '(\d{4})-(\d{1,2})-(\d{1,2})'
	begin = '2015-09-15'
	endday = '2022-06-23'
	if 'begin' in request.GET:
		begin = request.GET['begin']
		res = re.search(pattern, begin)
		if res:
			year = res.group(1)
			yue = res.group(2)
			ri = res.group(3)
			if len(yue) == 1:
				yue = '0' + yue
			if len(ri) == 1:
				ri = '0' + ri
			begin = year + '-' + yue + '-' + ri
		else:
			begin = '2015-09-15'
	else:
		begin = '2015-09-15'
	if 'end' in request.GET:
		endday = request.GET['end']
		res = re.search(pattern, endday)
		if res:
			year = res.group(1)
			yue = res.group(2)
			ri = res.group(3)
			if len(yue) == 1:
				yue = '0' + yue
			if len(ri) == 1:
				ri = '0' + ri
			endday = year + '-' + yue + '-' + ri
		else:
			endday = '2022-06-23'
	else:
		endday = '2022-06-23'

	# wordlist = list(jieba.cut(q))
	wordlist = list(jieba.lcut_for_search(q))
	for word in wordlist:
		word = word.strip()
	allnews = []

	##############检索数据##############
	start = time.perf_counter()
	# allnewstemp = game.objects.all()
	allnewstemp = Data.objects.all()
	all_news = []
	for item in allnewstemp:
		all_news.append(item)
	# if item.time >= begin and item.time <= endday:
	# 	all_news.append(item)

	dictnum = {}
	if len(wordlist) >= 3:
		for word in wordlist:
			if len(word) == 1:
				wordlist.remove(word)

	if len(wordlist) == 1:
		for item in all_news:
			if q in item.title:
				allnews.append(item)
		for item in all_news:
			if q in item.summary:
				allnews.append(item)
	else:
		max = 0
		for item in all_news:
			num = 0
			for word in wordlist:
				if word in item.title:
					num += 1
			if num > max:
				max = num
			# if dictnum.has_key(num):
			if num in dictnum:
				dictnum[num].append(item)
			else:
				dictnum[num] = []
				dictnum[num].append(item)
		while max > 0:
			# if dictnum.has_key(max):
			if max in dictnum:
				allnews.extend(dictnum[max])
			max -= 1
		max = 0
		dictnum = {}
		for item in all_news:
			num = 0
			for word in wordlist:
				if word in item.summary:
					num += 1
			if num > max:
				max = num
			# if dictnum.has_key(num):
			if num in dictnum:
				dictnum[num].append(item)
			else:
				dictnum[num] = []
				dictnum[num].append(item)
		while max > 0:
			# if dictnum.has_key(max):
			if max in dictnum:
				for n in dictnum[max]:
					if n not in allnews:
						allnews.append(n)
			max -= 1
	endtime = time.perf_counter()
	timing = endtime - start
	all_count = len(allnews)
	pag = Paginator(allnews, 10)
	if pag.num_pages > 10:
		page = int(pagenum)
		if page - 5 < 1:
			pageRange = range(1, 11)
		elif page + 5 > pag.num_pages:
			pageRange = range(page - 5, pag.num_pages + 1)
		else:
			pageRange = range(page - 5, page + 5)
	else:
		pageRange = pag.page_range
	newslist = pag.page(pagenum)
	return render(request, "search_result.html",
				  {'begin': begin, 'end': endday, 'all_news': newslist, 'time': timing, 'word': q, 'num': all_count,
				   'keywl': wordlist, 'range': pageRange})

def anly(request):

    if request.method == "POST":
        str1 = request.POST.get("txt")

        file = open('SearchEngine/stopwords.bat',encoding='utf-8')
        stopword = file.read()
        file.close()

        dict1={'词频': '如下所示'}
        # 算词频
        content = jieba.lcut(str1)

        dic = {}
        for word in content:
            if word not in dic:
                dic[word] = 1
            else:
                dic[word] += 1
        swd = sorted(list(dic.items()), key=lambda lst: lst[1], reverse=True)
        i=0
        for kword , times in swd:
            if kword not in stopword:
                dict1.update({kword: times})
                i += 1

        #算词汇量
        dict1.update({'词汇量': i})

        # 句子数：切完逗号['第一句', '第二句', '第三句', '']，会多一个，建议（number1）直接减1
        list1 = str1.split("。")
        number1 = len(list1)-1
        dict1 .update({'句子数': number1})

        # 算段落数
        para = 0
        if str1 == '':
            para = 0

        elif (' ' not in str1) :
            para = 1

        else:
            for i in str1:
                if i == ' ':
                    para += 1
        dict1.update({'段落数':para})


        return render(request,"anly_result.html",{"resultdict":dict1})
	# return redirect(reverse("zxy:login_teacher"))
    return render(request,"anly.html")
#fielddict = {'name':'张三','age':18}
#return render(request,'test.html',{'field':fielddict})


def anly_result(request):

    return render(request, "anly_result.html")

