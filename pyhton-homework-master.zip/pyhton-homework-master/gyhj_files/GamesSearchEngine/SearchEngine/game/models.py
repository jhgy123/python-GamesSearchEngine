# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
class Data(models.Model):
    title = models.CharField('标题', max_length = 50)
    address = models.CharField('对应链接', max_length=50)
    summary = models.TextField('摘要')

    class Meta:
        db_table = 'data'
        verbose_name = u'游戏详细信息'
        verbose_name_plural = verbose_name

# Create your models here.
