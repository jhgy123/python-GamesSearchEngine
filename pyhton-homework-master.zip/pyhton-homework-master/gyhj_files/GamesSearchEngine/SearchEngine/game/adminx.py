from game.models import Data
from asyncio.log import logger
from hashlib import md5

import xlrd as xlrd
from django.apps import apps
from django.contrib.auth.hashers import make_password
import xadmin
from xadmin.plugins.excel import excel_into_model

class DataAdmin(object):
    list_display = ['title', 'address', 'summary']
    search_fields = ['title', 'address', 'summary']
    list_filter = ['title', 'address', 'summary']
    list_per_page = 20
    # readonly_fields = ['t_id', 't_name']
    refresh_times = [10, 20, 30, 60]
    list_export = ('xls', 'xml', 'json')
    list_export_fields = ('title', 'address', 'summary')
    model_icon = 'fa fa-user'

    import_excel = True# 控制导入的开关
    def post(self, request, *args, **kwargs):
        if 'excel' in request.FILES:
            execl_file = request.FILES.get('excel')
            data = xlrd.open_workbook(filename=None, file_contents=request.FILES['excel'].read())
            try:
                appname_ = apps.get_model('game', 'Data')
                fields = appname_._meta.fields
                # 导入model,动态导入
                # exec('from %s.models import %s' % (appname, model_name))
            except:
                logger.info('model_name and appname is not exist')
            field_name = []
            # 只导入第一个sheet中的数据
            table = data.sheet_by_index(0)
            rows = table.nrows
            table_header = table.row_values(0)
            for cell in table_header:
                for name in fields:
                    if cell == name.verbose_name.__str__():
                        field_name.append(name.name)
            # if 'add_time' in field_name:
            #     field_name.remove('add_time')
            for row in range(1, rows):
                # 行的数据,创建对象,进行报错数据
                # exec('obj' + '=%s()' % model_name)
                data = Data()
                columns = len(field_name)
                for column in range(columns):
                    if 'title' == field_name[column]:
                        title = str(table.cell_value(row, column))
                        s_title = title
                        data.title = s_title
                    else:
                        exec('data.%s' % field_name[column] + '="""%s"""' % (table.cell_value(row, column)))
                # password = 'zxy@' + student.s_id
                # password = md5(password.encode(encoding='UTF-8')).hexdigest()
                # password = make_password(password)
                # student.s_password = password
                # student.is_active = True
                data.save()
        return super(DataAdmin, self).post(request, *args, **kwargs)

xadmin.site.register(Data, DataAdmin)